function reveal() {
    document.getElementById("hid").style.display = 'none';
}